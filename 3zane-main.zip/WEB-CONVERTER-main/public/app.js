/* 3Zane converter — front-end behaviour.
   Layout/markup mirrors the reference workspace; the wiring below talks to the
   local converter API (scrapr + ffmpeg) and keeps the Roblox publish action locked. */

(() => {
  'use strict';

  const $ = (sel, root = document) => root.querySelector(sel);
  const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));

  const panel = $('#converter');
  const resultList = $('#result-list');
  const statusEl = $('#status-message');
  const urlInput = $('#url-input');
  const detectBtn = $('#detect-button');
  const quotaList = $('#quota-list');

  const FORMAT_TITLES = {
    mp3: 'MP3 – 320kbps, universal',
    ogg: 'OGG – 256kbps, Roblox ready',
    wav: 'WAV – PCM lossless',
    flac: 'FLAC – true lossless',
    m4a: 'M4A – 256kbps, Apple',
    aac: 'AAC – 256kbps',
    opus: 'OPUS – 192kbps, efficient',
    wma: 'WMA – 192kbps, Windows',
  };

  const STAGE_TEXT = {
    idle: 'Tempel tautan atau unggah file audio untuk memulai.',
    detecting: 'Memeriksa informasi dan sumber audio…',
    ready: 'Siap dikonversi.',
    downloading: 'Mengunduh audio sumber…',
    converting: 'Mengonversi audio…',
    validating: 'Memastikan file hasil dapat diputar…',
    storing: 'Menyimpan hasil konversi…',
    done: 'Konversi selesai.',
  };

  const state = {
    mode: 'url',
    url: '',
    meta: null,
    format: 'ogg',
    speed: 2.3,
    pitch: 1,
    amplify: -2,
    robloxOriginal: false,
    robloxPlaybackSpeed: '0.4347',
    normalize: false,
    removeSilence: false,
    trimStart: '',
    trimEnd: '',
    converting: false,
    uploadFile: null,
    results: [],
  };

  /* --------------------------------------------------------------- utilities */

  function formatDuration(seconds) {
    const total = Math.max(0, Math.round(Number(seconds) || 0));
    const h = Math.floor(total / 3600);
    const m = Math.floor((total % 3600) / 60);
    const s = total % 60;
    if (h) return `${h}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
    return `${m}:${String(s).padStart(2, '0')}`;
  }

  function toast(message, type = 'success', duration = 3200) {
    const el = document.createElement('div');
    el.className = `app-toast app-toast--${type}`;
    el.textContent = message;
    $('#toast-container').appendChild(el);
    setTimeout(() => el.remove(), duration);
  }

  function setStatus(text, isError = false) {
    statusEl.textContent = text || '';
    statusEl.classList.toggle('error', Boolean(isError));
    statusEl.setAttribute('role', isError ? 'alert' : 'status');
    statusEl.setAttribute('aria-live', isError ? 'assertive' : 'polite');
  }

  /* ------------------------------------------------------- locked features */

  const devModal = $('#dev-modal');

  function openDevModal(title, body) {
    if (title) $('#dev-modal-title').textContent = title;
    if (body) $('#dev-modal-body').textContent = body;
    devModal.hidden = false;
    $('#dev-modal-close').focus();
  }

  function closeDevModal() {
    devModal.hidden = true;
  }

  $('#dev-modal-close').addEventListener('click', closeDevModal);
  devModal.addEventListener('click', (event) => {
    if (event.target === devModal) closeDevModal();
  });
  document.addEventListener('keydown', (event) => {
    if (event.key === 'Escape' && !devModal.hidden) closeDevModal();
  });

  /* ------------------------------------------------------------ derived values */

  const ROBLOX_MIN = 0.3334;
  const ROBLOX_MAX = 2;

  function playbackTarget() {
    const value = Number(state.robloxPlaybackSpeed);
    return Number.isFinite(value) && value >= ROBLOX_MIN && value <= ROBLOX_MAX ? value : null;
  }

  function effectiveSpeed() {
    if (state.robloxOriginal) {
      const target = playbackTarget();
      if (target) return 1 / target;
    }
    return state.speed;
  }

  function robloxPlaybackValue() {
    if (state.robloxOriginal) return playbackTarget() || 1;
    return state.speed === 1 ? 1 : 1 / state.speed;
  }

  function exportPitch() {
    const compensate = state.robloxOriginal || state.compensate !== false;
    return state.pitch * (compensate ? effectiveSpeed() : 1);
  }

  /* ---------------------------------------------------------------- rendering */

  function metaCardHtml() {
    const meta = state.meta;
    if (!meta) return '';
    const eyebrow = [
      meta.platform === 'upload' ? 'LOCAL UPLOAD' : String(meta.platform || '').toUpperCase(),
      meta.duration,
    ]
      .filter(Boolean)
      .join(' · ');

    const cover = meta.thumbnail
      ? `<img src="${escapeAttr(meta.thumbnail)}" alt="" />`
      : `<div class="audio-placeholder" aria-hidden="true">
           <span class="ap-bar" style="animation-delay:0ms"></span>
           <span class="ap-bar" style="animation-delay:80ms"></span>
           <span class="ap-bar" style="animation-delay:160ms"></span>
           <span class="ap-bar" style="animation-delay:240ms"></span>
           <span class="ap-bar" style="animation-delay:120ms"></span>
         </div>`;

    return `<div class="meta-card">
      <div class="cover-art">${cover}</div>
      <div>
        <span class="eyebrow">${escapeHtml(eyebrow)}</span>
        <h3>${escapeHtml(meta.title || 'Untitled audio')}</h3>
        <p class="muted">${escapeHtml(meta.artist || 'Unknown')}</p>
      </div>
    </div>`;
  }

  function formatOptionsHtml() {
    const formats = (state.meta && state.meta.formats) || ['ogg', 'mp3', 'wav', 'flac', 'm4a', 'aac', 'opus'];
    const buttons = formats
      .map(
        (f) => `<button class="format-option${state.format === f ? ' active' : ''}" type="button" data-format="${f}"
          title="${escapeAttr(FORMAT_TITLES[f] || '')}" aria-pressed="${state.format === f}">${f.toUpperCase()}</button>`
      )
      .join('');
    return `<div class="format-options" aria-label="Audio format"><span class="format-label">Audio format</span>${buttons}</div>`;
  }

  function robloxOriginalHtml() {
    const target = playbackTarget();
    const valid = Boolean(target);
    return `<div class="roblox-original-mode">
      <label class="check-label roblox-original-toggle">
        <input type="checkbox" data-toggle="robloxOriginal" ${state.robloxOriginal ? 'checked' : ''} />
        <span>
          <strong>Roblox Original Sound</strong>
          <small>Match source pitch and tempo after Roblox applies PlaybackSpeed; keep manual Pitch at 0%.</small>
        </span>
      </label>
      ${
        state.robloxOriginal
          ? `<label class="roblox-playback-target">Target Roblox PlaybackSpeed
              <input type="number" min="0.3334" max="2" step="0.0001" value="${escapeAttr(state.robloxPlaybackSpeed)}"
                aria-invalid="${valid ? 'false' : 'true'}" data-input="robloxPlaybackSpeed" />
              <small>${
                valid
                  ? `3Zane will convert at ${effectiveSpeed().toFixed(4)}x and compensate pitch automatically.`
                  : 'Use a value from 0.3334 to 2 so the conversion speed stays within 0.5x–3x.'
              }</small>
            </label>`
          : ''
      }
    </div>`;
  }

  function controlsHtml() {
    const speed = effectiveSpeed();
    const pitchPct = ((state.pitch - 1) * 100).toFixed(0);
    return `<div class="controls-grid controls-grid-3">
      <label>Speed <output id="out-speed">${speed.toFixed(state.robloxOriginal ? 4 : 1)}x</output>
        <input type="range" min="0.5" max="3" step="0.1" value="${state.speed}" data-input="speed"
          ${state.robloxOriginal ? 'disabled' : ''} />
      </label>
      <label>Amplify <output id="out-amplify">${state.amplify > 0 ? '+' : ''}${state.amplify} dB</output>
        <input type="range" min="-20" max="10" step="1" value="${state.amplify}" data-input="amplify" />
      </label>
      <label>Pitch <output id="out-pitch">${state.pitch > 1 ? '+' : ''}${pitchPct}%</output>
        <input type="range" min="0.5" max="2" step="0.05" value="${state.pitch}" data-input="pitch" />
      </label>
    </div>`;
  }

  function trimmerHtml() {
    return `<div class="trimmer-row">
      <span class="format-label">Trim audio</span>
      <div class="trimmer-inputs">
        <label class="trimmer-label">Start
          <input class="trimmer-input" type="text" value="${escapeAttr(state.trimStart)}" placeholder="e.g. 0:30" data-input="trimStart" />
        </label>
        <span class="trimmer-sep">→</span>
        <label class="trimmer-label">End
          <input class="trimmer-input" type="text" value="${escapeAttr(state.trimEnd)}" placeholder="e.g. 3:00" data-input="trimEnd" />
        </label>
        ${state.trimStart || state.trimEnd ? '<button class="trimmer-clear" type="button" data-action="clear-trim">✕ Clear</button>' : ''}
      </div>
    </div>`;
  }

  function playbackInfoHtml() {
    const value = robloxPlaybackValue();
    return `<div class="playback-info">
      <div class="playback-icon">⌁</div>
      <div class="playback-copy">
        <span class="eyebrow">Roblox playback speed</span>
        <strong id="out-playback">${value.toFixed(state.robloxOriginal ? 4 : 2)}</strong>
        <p>Set <code id="out-playback-code">Sound.PlaybackSpeed = ${value.toFixed(4)}</code> di Roblox supaya speed kembali normal.</p>
      </div>
      <button class="copy-playback" type="button" data-action="copy-playback">Copy</button>
    </div>`;
  }

  function toolsHtml() {
    const compensate = state.robloxOriginal || state.compensate !== false;
    const note = state.robloxOriginal
      ? `Use Roblox PlaybackSpeed ${robloxPlaybackValue().toFixed(4)} to bring the converted audio back toward the source pitch and tempo.`
      : `The preview here may sound higher; use Roblox PlaybackSpeed ${robloxPlaybackValue().toFixed(2)} to bring it back toward your selected pitch.`;
    return `<div class="tools-grid">
      <label class="check-label${state.robloxOriginal ? ' is-locked' : ''}">
        <input type="checkbox" data-toggle="compensate" ${compensate ? 'checked' : ''} ${state.robloxOriginal ? 'disabled' : ''} />Compensate pitch for Roblox
      </label>
      <label class="check-label">
        <input type="checkbox" data-toggle="normalize" ${state.normalize ? 'checked' : ''} /> Normalize volume
      </label>
      <label class="check-label">
        <input type="checkbox" data-toggle="removeSilence" ${state.removeSilence ? 'checked' : ''} /> Remove silence
      </label>
      <p class="muted pitch-compensation-note">Export pitch: ${exportPitch().toFixed(2)}x. ${note} Strong changes may add audio artifacts.</p>
    </div>`;
  }

  function actionHtml() {
    const disabled =
      state.converting ||
      (state.robloxOriginal && !playbackTarget()) ||
      (state.mode === 'url' && !state.meta) ||
      (state.mode === 'upload' && !state.uploadFile);

    return `<section class="conversion-action" aria-live="polite" aria-busy="${state.converting}">
      <button class="convert-button${state.converting ? ' btn-converting' : ''}" type="button" data-action="convert" ${disabled ? 'disabled' : ''}>
        ${state.converting ? '<span class="btn-shimmer"></span><span>Converting…</span>' : `Convert to ${state.format.toUpperCase()}`}
      </button>
      ${
        state.converting
          ? '<p class="conversion-status" role="status">Your audio is being processed. Keep this tab open and avoid reloading it.</p>'
          : ''
      }
    </section>`;
  }

  function renderAdvanced() {
    $$('.meta-card, .format-options, .roblox-original-mode, .controls-grid, .trimmer-row, .playback-info, .tools-grid, .conversion-action', panel).forEach(
      (node) => node.remove()
    );

    if (!state.meta) return;

    const html = [
      metaCardHtml(),
      formatOptionsHtml(),
      robloxOriginalHtml(),
      controlsHtml(),
      trimmerHtml(),
      playbackInfoHtml(),
      toolsHtml(),
      actionHtml(),
    ].join('');

    const holder = document.createElement('div');
    holder.innerHTML = html;
    const fragment = document.createDocumentFragment();
    while (holder.firstChild) fragment.appendChild(holder.firstChild);
    panel.insertBefore(fragment, resultList);
  }

  /* -------------------------------------------------------------- progress UI */

  function ensureProgressEl() {
    let el = $('#conversion-progress');
    if (!el) {
      el = document.createElement('div');
      el.id = 'conversion-progress';
      el.className = 'conversion-progress';
      el.setAttribute('role', 'progressbar');
      el.setAttribute('aria-label', 'Persentase proses konversi audio');
      el.setAttribute('aria-valuemin', '0');
      el.setAttribute('aria-valuemax', '100');
      el.innerHTML = '<div class="conversion-progress-track"><span style="width:0%"></span></div><small></small>';
      statusEl.insertAdjacentElement('afterend', el);
    }
    return el;
  }

  function updateProgress(percent, label) {
    const el = ensureProgressEl();
    const clamped = Math.max(0, Math.min(100, Number(percent) || 0));
    el.setAttribute('aria-valuenow', String(clamped));
    $('.conversion-progress-track span', el).style.width = `${clamped}%`;
    $('small', el).textContent = label || `${clamped}% · Proses konversi audio`;
  }

  function clearProgress() {
    const el = $('#conversion-progress');
    if (el) el.remove();
  }

  /* -------------------------------------------------------------- audio player */

  function createPlayer(src) {
    const wrap = document.createElement('div');
    wrap.className = 'custom-player';
    wrap.tabIndex = 0;
    wrap.setAttribute('aria-label', 'Audio player');
    wrap.innerHTML = `
      <audio preload="metadata" src="${escapeAttr(src)}"></audio>
      <canvas class="player-waveform"></canvas>
      <div class="player-controls">
        <button class="player-btn play-btn" type="button" aria-label="Play"
          style="width:44px;height:44px;border-radius:50%;font-size:14px">▶</button>
        <div class="player-seek-group">
          <span class="player-time" data-role="current">0:00</span>
          <input class="player-seek" type="range" min="0" max="0" step="0.1" value="0" aria-label="Seek" />
          <span class="player-time" data-role="total">0:00</span>
        </div>
        <button class="player-btn mute-btn" type="button" aria-label="Mute"
          style="width:36px;height:36px;font-size:16px">🔊</button>
        <input class="player-vol" type="range" min="0" max="1" step="0.05" value="1" aria-label="Volume" />
      </div>`;

    const audio = $('audio', wrap);
    const canvas = $('canvas', wrap);
    const playBtn = $('.play-btn', wrap);
    const seek = $('.player-seek', wrap);
    const volume = $('.player-vol', wrap);
    const muteBtn = $('.mute-btn', wrap);
    const currentEl = $('[data-role="current"]', wrap);
    const totalEl = $('[data-role="total"]', wrap);

    let ctx2d = null;
    let analyser = null;
    let audioCtx = null;
    let sourceNode = null;
    let raf = 0;
    let playing = false;
    let lastVolume = 1;

    function sizeCanvas() {
      const dpr = window.devicePixelRatio || 1;
      const w = canvas.clientWidth || 320;
      const h = canvas.clientHeight || 48;
      if (canvas.width !== w * dpr || canvas.height !== h * dpr) {
        canvas.width = w * dpr;
        canvas.height = h * dpr;
      }
      const ctx = canvas.getContext('2d');
      if (!ctx) return null;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      return { ctx, w, h };
    }

    function drawIdle() {
      const dims = sizeCanvas();
      if (!dims) return;
      const { ctx, w, h } = dims;
      ctx.clearRect(0, 0, w, h);
      const bars = 40;
      const step = w / (bars * 2);
      for (let i = 0; i < bars; i += 1) {
        const barH = 4 + Math.abs(Math.sin(i * 0.5)) * (h * 0.55);
        ctx.fillStyle = 'rgba(221, 194, 127, 0.25)';
        ctx.fillRect(i * (step * 2) + step / 2, h / 2 - barH / 2, step, barH);
      }
    }

    function drawLive() {
      const dims = sizeCanvas();
      if (!dims || !analyser) return;
      const { ctx, w, h } = dims;
      const bins = analyser.frequencyBinCount;
      const data = new Uint8Array(bins);
      analyser.getByteFrequencyData(data);
      ctx.clearRect(0, 0, w, h);
      const barW = (w / bins) * 2.5;
      let x = 0;
      for (let i = 0; i < bins; i += 1) {
        const barH = (data[i] / 255) * h;
        const hue = 210 + (data[i] / 255) * 80;
        ctx.fillStyle = `hsla(${hue}, 80%, 65%, 0.85)`;
        ctx.fillRect(x, h - barH, barW, barH);
        x += barW + 1;
      }
      raf = requestAnimationFrame(drawLive);
    }

    function initAnalyser() {
      if (audioCtx) return;
      const Ctx = window.AudioContext || window.webkitAudioContext;
      if (!Ctx) return;
      try {
        audioCtx = new Ctx();
        analyser = audioCtx.createAnalyser();
        analyser.fftSize = 256;
        sourceNode = audioCtx.createMediaElementSource(audio);
        sourceNode.connect(analyser);
        analyser.connect(audioCtx.destination);
      } catch {
        audioCtx = null;
        analyser = null;
      }
    }

    playBtn.addEventListener('click', () => {
      initAnalyser();
      if (audioCtx && audioCtx.state === 'suspended') audioCtx.resume();
      if (audio.paused) audio.play().catch(() => toast('Preview tidak bisa diputar di browser ini.', 'error'));
      else audio.pause();
    });

    audio.addEventListener('play', () => {
      playing = true;
      playBtn.textContent = '⏸';
      playBtn.setAttribute('aria-label', 'Pause');
      cancelAnimationFrame(raf);
      if (analyser) drawLive();
    });

    audio.addEventListener('pause', () => {
      playing = false;
      playBtn.textContent = '▶';
      playBtn.setAttribute('aria-label', 'Play');
      cancelAnimationFrame(raf);
      drawIdle();
    });

    audio.addEventListener('ended', () => {
      audio.currentTime = 0;
      playing = false;
      playBtn.textContent = '▶';
      cancelAnimationFrame(raf);
      drawIdle();
    });

    audio.addEventListener('timeupdate', () => {
      currentEl.textContent = formatDuration(audio.currentTime);
      seek.value = String(audio.currentTime);
    });

    audio.addEventListener('loadedmetadata', () => {
      seek.max = String(audio.duration || 0);
      totalEl.textContent = formatDuration(audio.duration);
    });

    seek.addEventListener('input', () => {
      audio.currentTime = Number(seek.value);
      currentEl.textContent = formatDuration(audio.currentTime);
    });

    volume.addEventListener('input', () => {
      audio.volume = Number(volume.value);
      lastVolume = audio.volume;
      muteBtn.textContent = audio.volume === 0 ? '🔇' : '🔊';
    });

    muteBtn.addEventListener('click', () => {
      if (audio.volume > 0) {
        lastVolume = audio.volume;
        audio.volume = 0;
        volume.value = '0';
        muteBtn.textContent = '🔇';
      } else {
        audio.volume = lastVolume || 1;
        volume.value = String(audio.volume);
        muteBtn.textContent = '🔊';
      }
    });

    const observer = new ResizeObserver(() => {
      if (!playing) drawIdle();
    });
    observer.observe(canvas);
    drawIdle();

    return wrap;
  }

  /* --------------------------------------------------------------- results */

  function addResult(result) {
    state.results.push(result);

    if (!$('.results-heading', resultList)) {
      const heading = document.createElement('div');
      heading.className = 'results-heading';
      heading.innerHTML = '<span class="eyebrow">Ready</span><strong></strong>';
      resultList.prepend(heading);
    }
    const count = $('.results-heading strong', resultList);
    if (count) count.textContent = `${state.results.length} file${state.results.length > 1 ? 's' : ''} converted`;

    const card = document.createElement('div');
    card.className = 'result-card';
    card.innerHTML = `
      <div>
        <span class="eyebrow">Ready</span>
        <h3>${escapeHtml(result.file.name)}</h3>
        <p class="muted">${result.file.size_mb} MB · Playback normal ${Number(result.playback_speed_normal).toFixed(2)}${
          result.roblox_pitch_compensation ? ' · Roblox pitch compensated' : ''
        }</p>
        ${robloxLimitWarning(result)}
      </div>
      <div class="result-actions">
        <a class="download-button" href="${escapeAttr(result.file.url)}" download="${escapeAttr(result.file.name)}">↓ Download file</a>
        <button class="share-button" type="button" data-action="share" data-url="${escapeAttr(result.file.preview_url)}" title="Copy preview link">🔗 Share</button>
      </div>
      <div class="publish-row">
        <button class="publish-roblox-btn" type="button" data-action="publish">⌘ Publish to Roblox</button>
        <span class="publish-hint">API key &amp; Creator ID belum di-save</span>
      </div>`;

    const player = createPlayer(result.file.preview_url || result.file.url);
    card.insertBefore(player, card.querySelector('.result-actions'));
    resultList.appendChild(card);
  }

  function robloxLimitWarning(result) {
    const size = Number.parseFloat(result.file.size_mb);
    const seconds = parseDuration(result.duration);
    if (size > 20) return `<p class="roblox-limit-warn">⚠ File is ${size}MB — exceeds Roblox's 20MB limit</p>`;
    if (seconds > 420) return `<p class="roblox-limit-warn">⚠ Duration ${result.duration} exceeds Roblox's 7-minute limit</p>`;
    return '';
  }

  function parseDuration(value) {
    if (typeof value !== 'string') return 0;
    const parts = value.split(':').map(Number);
    if (parts.some((n) => !Number.isFinite(n))) return 0;
    return parts.length === 3 ? parts[0] * 3600 + parts[1] * 60 + parts[2] : parts[0] * 60 + parts[1];
  }

  /* --------------------------------------------------------------- actions */

  async function detect() {
    const url = urlInput.value.trim();
    if (!url) {
      setStatus('Tempel tautan audio terlebih dahulu.', true);
      return;
    }

    detectBtn.disabled = true;
    detectBtn.textContent = '...';
    setStatus(STAGE_TEXT.detecting);

    try {
      const res = await fetch('/api/detect', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Gagal membaca tautan.');

      state.url = url;
      state.meta = {
        platform: data.platform,
        title: data.title,
        artist: data.artist,
        thumbnail: data.thumbnail,
        duration: data.duration,
        durationSec: data.durationSec,
        formats: data.formats,
        resolvedVia: data.resolvedVia,
      };
      state.format = (data.formats || []).includes(state.format) ? state.format : (data.formats || ['ogg'])[0];

      renderAdvanced();
      setStatus(`Siap dikonversi · sumber: ${data.resolvedVia}`);
    } catch (err) {
      state.meta = null;
      renderAdvanced();
      setStatus(err.message, true);
    } finally {
      detectBtn.disabled = false;
      detectBtn.textContent = 'Detect';
    }
  }

  async function convert() {
    if (state.converting) return;

    if (state.mode === 'url' && !state.meta) {
      setStatus('Detect tautan dulu sebelum konversi.', true);
      return;
    }
    if (state.mode === 'upload' && !state.uploadFile) {
      setStatus('Pilih file audio dulu.', true);
      return;
    }

    state.converting = true;
    renderAdvanced();
    setStatus('Memulai konversi…');
    updateProgress(2, '2% · Menyiapkan konversi');

    const payload = {
      format: state.format,
      speed: effectiveSpeed(),
      pitch: state.pitch,
      amplify: state.amplify,
      normalize: state.normalize,
      removeSilence: state.removeSilence,
      robloxPitchCompensation: state.robloxOriginal || state.compensate !== false,
      trimStart: state.trimStart,
      trimEnd: state.trimEnd,
    };

    try {
      let res;
      if (state.mode === 'upload') {
        const form = new FormData();
        form.append('file', state.uploadFile);
        Object.entries(payload).forEach(([k, v]) => form.append(k, String(v)));
        res = await fetch('/api/convert-upload', { method: 'POST', body: form });
      } else {
        res = await fetch('/api/convert', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ url: state.url, ...payload }),
        });
      }

      const start = await res.json();
      if (!res.ok) throw new Error(start.error || 'Server menolak permintaan konversi.');

      const result = await pollJob(start.progressId);
      addResult(result);
      setStatus(STAGE_TEXT.done);
      clearProgress();
      toast('Konversi selesai.', 'success');
      refreshAccount();
      refreshActivity();
    } catch (err) {
      setStatus(err.message || 'Konversi gagal.', true);
      clearProgress();
      toast(err.message || 'Konversi gagal.', 'error', 5000);
    } finally {
      state.converting = false;
      renderAdvanced();
    }
  }

  async function pollJob(id) {
    for (let i = 0; i < 600; i += 1) {
      await new Promise((resolve) => setTimeout(resolve, 900));

      const res = await fetch(`/api/convert-progress/${encodeURIComponent(id)}`);
      if (!res.ok) continue;
      const job = await res.json();

      if (job.percent !== null && job.percent !== undefined) {
        updateProgress(job.percent, `${job.percent}% · ${job.message}`);
      } else if (job.message) {
        setStatus(job.message);
      }

      if (job.stage === 'complete' && job.result) return job.result;
      if (job.stage === 'error') throw new Error(job.error || 'Konversi gagal di server.');
    }
    throw new Error('Konversi melebihi batas waktu.');
  }

  /* --------------------------------------------------------------- wiring */

  panel.addEventListener('click', (event) => {
    const formatBtn = event.target.closest('[data-format]');
    if (formatBtn) {
      state.format = formatBtn.dataset.format;
      renderAdvanced();
      return;
    }

    const actionEl = event.target.closest('[data-action]');
    if (!actionEl) return;
    const action = actionEl.dataset.action;

    if (action === 'convert') {
      convert();
    } else if (action === 'publish') {
      openDevModal();
    } else if (action === 'copy-playback') {
      navigator.clipboard?.writeText(robloxPlaybackValue().toFixed(4));
      toast('Copied!', 'success', 1500);
    } else if (action === 'clear-trim') {
      state.trimStart = '';
      state.trimEnd = '';
      renderAdvanced();
    } else if (action === 'share') {
      const url = new URL(actionEl.dataset.url, window.location.origin).href;
      navigator.clipboard?.writeText(url);
      actionEl.textContent = '✅ Copied!';
      setTimeout(() => (actionEl.textContent = '🔗 Share'), 1800);
    }
  });

  panel.addEventListener('input', (event) => {
    const el = event.target;
    const key = el.dataset.input;
    if (!key) return;

    if (key === 'robloxPlaybackSpeed') {
      state.robloxPlaybackSpeed = el.value;
      const valid = playbackTarget() !== null;
      el.setAttribute('aria-invalid', valid ? 'false' : 'true');
      const out = $('#out-speed');
      if (out) out.textContent = `${effectiveSpeed().toFixed(4)}x`;
      const pb = $('#out-playback');
      if (pb) pb.textContent = robloxPlaybackValue().toFixed(4);
      const pbCode = $('#out-playback-code');
      if (pbCode) pbCode.textContent = `Sound.PlaybackSpeed = ${robloxPlaybackValue().toFixed(4)}`;
      const convertBtn = $('[data-action="convert"]', panel);
      if (convertBtn) convertBtn.disabled = !valid;
      return;
    }

    if (key === 'trimStart' || key === 'trimEnd') {
      state[key] = el.value;
      return;
    }

    const value = Number(el.value);
    state[key] = value;

    if (key === 'speed') {
      const out = $('#out-speed');
      if (out) out.textContent = `${effectiveSpeed().toFixed(1)}x`;
      const pb = $('#out-playback');
      if (pb) pb.textContent = robloxPlaybackValue().toFixed(2);
      const pbCode = $('#out-playback-code');
      if (pbCode) pbCode.textContent = `Sound.PlaybackSpeed = ${robloxPlaybackValue().toFixed(4)}`;
    } else if (key === 'amplify') {
      const out = $('#out-amplify');
      if (out) out.textContent = `${value > 0 ? '+' : ''}${value} dB`;
    } else if (key === 'pitch') {
      const out = $('#out-pitch');
      if (out) out.textContent = `${value > 1 ? '+' : ''}${((value - 1) * 100).toFixed(0)}%`;
    }
  });

  panel.addEventListener('change', (event) => {
    const toggle = event.target.dataset.toggle;
    if (!toggle) return;
    if (toggle === 'compensate') state.compensate = event.target.checked;
    else state[toggle] = event.target.checked;
    renderAdvanced();
  });

  detectBtn.addEventListener('click', detect);

  urlInput.addEventListener('keydown', (event) => {
    if (event.key === 'Enter') {
      event.preventDefault();
      detect();
    }
  });

  urlInput.addEventListener('input', () => {
    if (urlInput.value.trim() !== (state.meta && state.url)) {
      state.meta = null;
      renderAdvanced();
      setStatus(STAGE_TEXT.idle);
    }
  });

  // Mode tabs
  $$('.converter-mode').forEach((btn) => {
    btn.addEventListener('click', () => {
      state.mode = btn.dataset.mode;
      $$('.converter-mode').forEach((b) => {
        const active = b === btn;
        b.classList.toggle('active', active);
        b.setAttribute('aria-selected', String(active));
      });
      $('#mode-url').hidden = state.mode !== 'url';
      $('#mode-upload').hidden = state.mode !== 'upload';
      $('#panel-title').textContent = state.mode === 'upload' ? 'Turn a file into sound.' : 'Turn a link into sound.';
      state.meta = null;
      renderAdvanced();
      setStatus(STAGE_TEXT.idle);
    });
  });

  // Upload handling
  const uploadInput = $('#audio-upload');
  uploadInput.addEventListener('change', () => {
    const file = uploadInput.files && uploadInput.files[0];
    if (!file) return;
    if (file.size > 50 * 1024 * 1024) {
      setStatus('File melebihi 50 MB.', true);
      return;
    }
    state.uploadFile = file;
    state.meta = {
      platform: 'upload',
      title: file.name.replace(/\.[^.]+$/, ''),
      artist: 'Local upload',
      thumbnail: null,
      duration: '',
      formats: ['ogg', 'mp3', 'wav', 'flac', 'm4a', 'aac', 'opus', 'wma'],
    };
    $('#upload-title').textContent = 'Choose another audio file';
    const list = $('#upload-file-list');
    list.hidden = false;
    list.innerHTML = `<div class="upload-file"><span>♫</span><div><strong>${escapeHtml(file.name)}</strong>
      <small>${(file.size / (1024 * 1024)).toFixed(2)} MB</small></div>
      <button type="button" aria-label="Remove ${escapeAttr(file.name)}" data-remove-upload>×</button></div>`;
    renderAdvanced();
    setStatus('Siap dikonversi.');
  });

  $('#upload-file-list').addEventListener('click', (event) => {
    if (!event.target.closest('[data-remove-upload]')) return;
    uploadInput.value = '';
    state.uploadFile = null;
    state.meta = null;
    $('#upload-file-list').hidden = true;
    $('#upload-title').textContent = 'Drop an audio file here';
    renderAdvanced();
    setStatus(STAGE_TEXT.idle);
  });

  // Drag & drop for upload mode
  const uploadLabel = $('#upload-label');
  ['dragover', 'dragleave', 'drop'].forEach((type) => {
    uploadLabel.addEventListener(type, (event) => {
      event.preventDefault();
      uploadLabel.classList.toggle('drag-active', type === 'dragover');
      if (type === 'drop' && event.dataTransfer.files.length) {
        uploadInput.files = event.dataTransfer.files;
        uploadInput.dispatchEvent(new Event('change'));
      }
    });
  });

  // Locked navigation targets keep the workspace honest about what exists here.
  $$('[data-nav]').forEach((link) => {
    link.addEventListener('click', (event) => {
      event.preventDefault();
      openDevModal('Halaman belum tersedia', 'Build ini fokus ke converter. Halaman lain di workspace 3Zane belum diaktifkan.');
    });
  });

  $$('[data-locked]').forEach((el) => {
    el.addEventListener('click', () => {
      openDevModal('Login belum aktif', 'Discord login tidak diaktifkan di build lokal ini. Converter tetap bisa dipakai tanpa akun.');
    });
  });

  // Mobile sidebar
  const toggle = $('.mobile-menu-toggle');
  if (toggle) {
    toggle.addEventListener('click', () => {
      const sidebar = $('#primary-navigation');
      const open = sidebar.classList.toggle('open');
      toggle.setAttribute('aria-expanded', String(open));
    });
  }

  /* --------------------------------------------------------- account/activity */

  async function refreshAccount() {
    try {
      const res = await fetch('/api/account');
      const data = await res.json();
      const plan = data.accountPlan;
      const used = plan.dailyUsage.conversion;
      const limit = plan.limits.conversionsPerDay;

      $('#quota-badge').innerHTML = `<strong>${plan.tier.toUpperCase()}</strong><span>Convert: ${Math.max(
        0,
        limit - used
      )}/${limit} sisa hari ini · ${plan.limits.concurrentConversions} paralel</span>`;
      $('#quota-tier').textContent = plan.tier.toUpperCase();

      const rows = [
        { label: 'Convert', limit, used, unit: 'conversions' },
        { label: 'Roblox publish', limit: plan.limits.publishesPerDay, used: 0, unit: 'publishes' },
        { label: 'AI chats', limit: plan.limits.chatsPerDay, used: 0, unit: 'chats' },
      ];

      quotaList.innerHTML = rows
        .map((row) => {
          const pct = row.limit > 0 ? Math.min(100, (row.used / row.limit) * 100) : 0;
          const text = `${row.used.toLocaleString()} / ${row.limit.toLocaleString()} used · ${Math.max(
            0,
            row.limit - row.used
          ).toLocaleString()} left`;
          return `<div class="account-quota-row">
            <div><strong>${row.label}</strong><span>${text}</span></div>
            <div class="account-quota-track" aria-label="${row.label} quota used"><span style="width:${pct}%"></span></div>
          </div>`;
        })
        .join('');
    } catch {
      /* ignore — the panel still works */
    }
  }

  async function refreshActivity() {
    try {
      const res = await fetch('/api/activity');
      const data = await res.json();
      const list = data.activity || [];
      const container = $('#act-list');
      const empty = $('#act-empty');

      if (!list.length) {
        container.innerHTML = '';
        empty.hidden = false;
        return;
      }

      empty.hidden = true;
      container.innerHTML = list
        .map((item) => {
          const failed = item.status === 'failed';
          return `<div class="act-row${failed ? ' act-row--failed' : ''}">
            <div class="act-avatar">
              <span class="act-avatar-initial">${escapeHtml((item.username || 'Y').slice(0, 1).toUpperCase())}</span>
              <span class="act-type-dot act-type-dot--${failed ? 'failed' : 'convert'}"></span>
            </div>
            <div class="act-body">
              <div class="act-top-row">
                <strong class="act-username">${escapeHtml(item.username || 'You')}</strong>
                <span class="act-action-label">${failed ? 'failed to convert' : 'converted'}</span>
                <span class="act-status-dot ${failed ? 'fail' : 'ok'}"></span>
              </div>
              <div class="act-track-title" title="${escapeAttr(item.title || '')}">${escapeHtml(item.title || '')}</div>
              ${item.artist && item.artist !== 'Unknown' ? `<div class="act-artist">${escapeHtml(item.artist)}</div>` : ''}
              <div class="act-meta-row">
                <span class="act-platform-chip">${escapeHtml(String(item.platform || '').toUpperCase())}</span>
                ${item.format ? `<span class="act-format-chip">${escapeHtml(String(item.format).toUpperCase())}</span>` : ''}
                ${item.duration ? `<span class="act-pill">⏱ ${escapeHtml(item.duration)}</span>` : ''}
                ${item.fileSizeMb ? `<span class="act-pill">${item.fileSizeMb} MB</span>` : ''}
              </div>
              ${failed && item.errorMessage ? `<div class="act-error-msg">${escapeHtml(item.errorMessage.slice(0, 80))}</div>` : ''}
              <time class="act-time" datetime="${escapeAttr(item.createdAt)}">${timeAgo(item.createdAt)}</time>
            </div>
          </div>`;
        })
        .join('');
    } catch {
      /* ignore */
    }
  }

  function timeAgo(iso) {
    const diff = Date.now() - new Date(iso).getTime();
    const s = Math.floor(diff / 1000);
    if (s < 5) return 'just now';
    if (s < 60) return `${s}s ago`;
    const m = Math.floor(s / 60);
    if (m < 60) return `${m}m ago`;
    const h = Math.floor(m / 60);
    return h < 24 ? `${h}h ago` : `${Math.floor(h / 24)}d ago`;
  }

  function escapeHtml(value) {
    return String(value == null ? '' : value).replace(/[&<>"']/g, (ch) => {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[ch];
    });
  }

  function escapeAttr(value) {
    return escapeHtml(value);
  }

  /* --------------------------------------------------------------- bootstrap */

  setTimeout(() => {
    const splash = document.getElementById('splash');
    if (!splash) return;
    splash.classList.add('hidden');
    setTimeout(() => splash.remove(), 420);
  }, 1800);

  setStatus(STAGE_TEXT.idle);
  refreshAccount();
  refreshActivity();
  setInterval(refreshActivity, 15000);

  // Same deep-link the reference app uses: /converter?source=<url>
  const sourceParam = new URLSearchParams(window.location.search).get('source');
  if (sourceParam) {
    urlInput.value = sourceParam;
    detect();
  }
})();
