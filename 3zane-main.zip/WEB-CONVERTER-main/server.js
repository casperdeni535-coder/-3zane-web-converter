'use strict';

const path = require('path');
const fs = require('fs');
const fsp = fs.promises;
const { randomUUID } = require('crypto');

const express = require('express');
const multer = require('multer');

const { fetchAudio, detectPlatform, splitArtistTitle } = require('./lib/resolve');
const { convertAudio, probeFile, availableFormats, FORMATS } = require('./lib/convert');

const app = express();
const PORT = Number(process.env.PORT) || 3000;

const PUBLIC_DIR = path.join(__dirname, 'public');
const OUT_DIR = path.join(__dirname, 'data', 'out');
const TMP_DIR = path.join(__dirname, 'data', 'tmp');
fs.mkdirSync(OUT_DIR, { recursive: true });
fs.mkdirSync(TMP_DIR, { recursive: true });

app.use(express.json({ limit: '2mb' }));
app.use(express.static(PUBLIC_DIR, { extensions: ['html'], maxAge: 0 }));

const upload = multer({
  dest: TMP_DIR,
  limits: { fileSize: 50 * 1024 * 1024 },
});

/* --------------------------------------------------------------- in-memory state */

const jobs = new Map();
const activity = [];
const ACTIVITY_FILE = path.join(__dirname, 'data', 'activity.json');

const stats = {
  totalConversions: 0,
  conversionsToday: 0,
  formatsUsed: new Set(),
  day: new Date().toDateString(),
};

const LIMITS = { conversionsPerDay: 25, concurrentConversions: 2, publishesPerDay: 10, chatsPerDay: 20 };

// Keep the activity feed and counters across restarts.
try {
  const saved = JSON.parse(fs.readFileSync(ACTIVITY_FILE, 'utf8'));
  if (Array.isArray(saved.activity)) activity.push(...saved.activity.slice(0, 40));
  if (saved.stats && typeof saved.stats === 'object') {
    stats.totalConversions = Number(saved.stats.totalConversions) || 0;
    stats.day = typeof saved.stats.day === 'string' ? saved.stats.day : stats.day;
    stats.conversionsToday = saved.stats.day === new Date().toDateString() ? Number(saved.stats.conversionsToday) || 0 : 0;
    (saved.stats.formatsUsed || []).forEach((f) => stats.formatsUsed.add(f));
  }
} catch {
  /* first run */
}

let persistTimer = null;
function persistActivity() {
  if (persistTimer) return;
  persistTimer = setTimeout(() => {
    persistTimer = null;
    const payload = {
      activity,
      stats: {
        totalConversions: stats.totalConversions,
        conversionsToday: stats.conversionsToday,
        day: stats.day,
        formatsUsed: Array.from(stats.formatsUsed),
      },
    };
    fsp.writeFile(ACTIVITY_FILE, JSON.stringify(payload)).catch(() => {});
  }, 400);
}

function rollDay() {
  const today = new Date().toDateString();
  if (stats.day !== today) {
    stats.day = today;
    stats.conversionsToday = 0;
  }
}

function slug(value) {
  return (
    String(value || 'audio')
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/^-+|-+$/g, '')
      .slice(0, 60) || 'audio'
  );
}

function pushActivity(entry) {
  activity.unshift({ ...entry, createdAt: new Date().toISOString() });
  if (activity.length > 40) activity.length = 40;
  persistActivity();
}

/* ------------------------------------------------------------------- job engine */

function createJob() {
  const id = randomUUID();
  const job = {
    id,
    stage: 'queued',
    message: 'Menyiapkan konversi…',
    percent: null,
    result: null,
    error: null,
    createdAt: Date.now(),
  };
  jobs.set(id, job);
  return job;
}

function setStage(job, stage, message, percent = null) {
  job.stage = stage;
  job.message = message;
  job.percent = percent;
}

async function runPipeline(job, input, options) {
  const workDir = path.join(TMP_DIR, job.id);
  await fsp.mkdir(workDir, { recursive: true });

  try {
    let sourceFile;
    let meta;

    if (input.kind === 'upload') {
      setStage(job, 'metadata', 'Memeriksa informasi audio…');
      const probed = await probeFile(input.filePath);
      const parsed = splitArtistTitle(probed.title || input.originalName.replace(/\.[^.]+$/, ''), probed.artist || '');
      meta = {
        platform: 'upload',
        title: parsed.title,
        artist: parsed.artist || 'Local upload',
        thumbnail: null,
        durationSec: probed.durationSec,
        via: 'upload',
      };
      sourceFile = input.filePath;
    } else {
      setStage(job, 'metadata', 'Memeriksa informasi dan sumber audio…');
      const fetched = await fetchAudio(
        input.url,
        workDir,
        (info) => {
          meta = info;
          job.meta = info;
        },
        (pct) => setStage(job, 'downloading', 'Mengunduh audio sumber…', Math.round(pct * 0.4))
      );
      sourceFile = fetched.filePath;
      meta = job.meta || meta;
    }

    if (!meta) throw new Error('Metadata audio tidak bisa dibaca.');

    setStage(job, 'converting', `Mengonversi audio ke ${options.format.toUpperCase()}…`, 45);

    const fileName = `${slug(meta.title)}-${job.id.slice(0, 8)}.${FORMATS[options.format]?.ext || 'ogg'}`;
    const outputPath = path.join(OUT_DIR, fileName);

    const converted = await convertAudio(sourceFile, outputPath, options, (pct) => {
      setStage(job, 'converting', `Mengonversi audio ke ${options.format.toUpperCase()}…`, 45 + Math.round(pct * 0.45));
    });

    setStage(job, 'validating', 'Memastikan file hasil dapat diputar…', 94);

    const stat = await fsp.stat(converted.filePath);
    if (stat.size < 1024) throw new Error('File hasil konversi kosong.');

    setStage(job, 'storing', 'Menyimpan hasil konversi…', 98);

    const durationSec = converted.durationSec || meta.durationSec || 0;
    const result = {
      title: meta.title,
      artist: meta.artist,
      platform: meta.platform,
      format: options.format,
      duration: formatDuration(durationSec),
      playback_speed_normal: Number(options.speed) || 1,
      roblox_pitch_compensation: Boolean(options.robloxPitchCompensation),
      resolvedVia: meta.via || 'scrapr',
      file: {
        name: fileName,
        size_mb: Number((stat.size / (1024 * 1024)).toFixed(2)),
        url: `/api/file/${encodeURIComponent(fileName)}`,
        preview_url: `/api/preview/${encodeURIComponent(fileName)}`,
        local_url: `/api/preview/${encodeURIComponent(fileName)}`,
      },
    };

    job.result = result;
    setStage(job, 'complete', 'Konversi selesai.', 100);

    rollDay();
    stats.totalConversions += 1;
    stats.conversionsToday += 1;
    stats.formatsUsed.add(options.format);

    pushActivity({
      username: 'You',
      status: 'success',
      activityType: 'convert',
      title: meta.title,
      artist: meta.artist,
      platform: meta.platform,
      sourceType: input.kind === 'upload' ? 'file-upload' : 'url',
      format: options.format,
      duration: result.duration,
      fileSizeMb: result.file.size_mb,
      via: meta.via,
    });
  } catch (err) {
    console.error('[pipeline]', err);
    job.error = err.message || 'Konversi gagal.';
    setStage(job, 'error', job.error, null);
    pushActivity({
      username: 'You',
      status: 'failed',
      activityType: 'convert',
      title: input.kind === 'upload' ? input.originalName : input.url,
      platform: input.kind === 'upload' ? 'upload' : detectPlatform(input.url),
      errorMessage: job.error,
      sourceType: input.kind === 'upload' ? 'file-upload' : 'url',
    });
  } finally {
    fsp.rm(workDir, { recursive: true, force: true }).catch(() => {});
    if (input.kind === 'upload') fsp.rm(input.filePath, { force: true }).catch(() => {});
  }
}

function formatDuration(seconds) {
  const total = Math.max(0, Math.round(Number(seconds) || 0));
  const h = Math.floor(total / 3600);
  const m = Math.floor((total % 3600) / 60);
  const s = total % 60;
  if (h) return `${h}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
  return `${m}:${String(s).padStart(2, '0')}`;
}

function normaliseOptions(body = {}) {
  const format = availableFormats().includes(body.format) ? body.format : 'ogg';
  return {
    format,
    speed: clampNumber(body.speed, 0.5, 3, 1),
    pitch: clampNumber(body.pitch, 0.5, 2, 1),
    amplify: clampNumber(body.amplify, -20, 10, 0),
    normalize: Boolean(body.normalize),
    removeSilence: Boolean(body.removeSilence),
    robloxPitchCompensation: Boolean(body.robloxPitchCompensation),
    trimStart: typeof body.trimStart === 'string' ? body.trimStart : '',
    trimEnd: typeof body.trimEnd === 'string' ? body.trimEnd : '',
  };
}

function clampNumber(value, min, max, fallback) {
  const n = Number(value);
  if (!Number.isFinite(n)) return fallback;
  return Math.min(max, Math.max(min, n));
}

/* ---------------------------------------------------------------------- routes */

app.get('/api/account', (req, res) => {
  rollDay();
  res.json({
    authenticated: true,
    user: { id: 'local', username: 'guest', global_name: 'Guest creator', plan: 'free' },
    accountPlan: {
      tier: 'free',
      limits: LIMITS,
      dailyUsage: { conversion: stats.conversionsToday, publishing: 0, spooferAssets: 0, chatAi: 0 },
    },
  });
});

app.get('/api/activity', (req, res) => {
  res.json({ activity });
});

app.post('/api/detect', async (req, res) => {
  const url = typeof req.body?.url === 'string' ? req.body.url.trim() : '';
  if (!url) return res.status(400).json({ error: 'URL kosong.' });
  if (!/^https?:\/\//i.test(url)) return res.status(400).json({ error: 'URL harus dimulai dengan http:// atau https://' });

  const platform = detectPlatform(url);
  if (platform === 'unknown') {
    return res.status(422).json({
      error: 'Platform belum didukung. Coba tautan YouTube, SoundCloud, Spotify, atau Apple Music.',
    });
  }

  try {
    const source = await require('./lib/resolve').resolveSource(url);
    res.json({
      platform: source.platform,
      title: source.title,
      artist: source.artist,
      thumbnail: source.thumbnail,
      durationSec: source.durationSec,
      duration: source.durationSec ? formatDuration(source.durationSec) : '',
      resolvedVia: source.via,
      method: source.method,
      formats: availableFormats(),
    });
  } catch (err) {
    console.error('[detect]', err);
    res.status(502).json({ error: err.message || 'Gagal membaca tautan.' });
  }
});

app.post('/api/convert', (req, res) => {
  const url = typeof req.body?.url === 'string' ? req.body.url.trim() : '';
  if (!url) return res.status(400).json({ error: 'URL kosong.' });
  if (!/^https?:\/\//i.test(url)) return res.status(400).json({ error: 'URL tidak valid.' });

  rollDay();
  if (stats.conversionsToday >= LIMITS.conversionsPerDay) {
    return res.status(429).json({ error: 'Kuota konversi harian habis.' });
  }

  const options = normaliseOptions(req.body);
  const job = createJob();
  res.json({ accepted: true, progressId: job.id });

  runPipeline(job, { kind: 'url', url }, options).catch((err) => console.error('[convert]', err));
});

app.post('/api/convert-upload', upload.single('file'), (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'File audio tidak ditemukan.' });

  rollDay();
  if (stats.conversionsToday >= LIMITS.conversionsPerDay) {
    return res.status(429).json({ error: 'Kuota konversi harian habis.' });
  }

  const options = normaliseOptions(req.body);
  const job = createJob();
  res.json({ accepted: true, progressId: job.id });

  runPipeline(job, { kind: 'upload', filePath: req.file.path, originalName: req.file.originalname }, options).catch((err) =>
    console.error('[convert-upload]', err)
  );
});

app.get('/api/convert-progress/:id', (req, res) => {
  const job = jobs.get(req.params.id);
  if (!job) return res.status(404).json({ error: 'Job tidak ditemukan.' });

  res.json({
    stage: job.stage,
    message: job.message,
    percent: job.percent,
    result: job.result,
    error: job.error,
    meta: job.meta || null,
  });

  if (job.stage === 'complete' || job.stage === 'error') {
    setTimeout(() => jobs.delete(job.id), 120000);
  }
});

function resolveOutFile(name) {
  const safe = path.basename(decodeURIComponent(name));
  const full = path.join(OUT_DIR, safe);
  if (!full.startsWith(OUT_DIR)) return null;
  if (!fs.existsSync(full)) return null;
  return full;
}

app.get('/api/file/:name', (req, res) => {
  const file = resolveOutFile(req.params.name);
  if (!file) return res.status(404).json({ error: 'File tidak ditemukan.' });
  res.download(file, path.basename(file));
});

app.get('/api/preview/:name', (req, res) => {
  const file = resolveOutFile(req.params.name);
  if (!file) return res.status(404).json({ error: 'File tidak ditemukan.' });
  res.setHeader('Content-Type', mimeFor(file));
  res.setHeader('Cache-Control', 'no-store');
  res.sendFile(file);
});

function mimeFor(file) {
  const ext = path.extname(file).toLowerCase();
  return (
    {
      '.mp3': 'audio/mpeg',
      '.ogg': 'audio/ogg',
      '.wav': 'audio/wav',
      '.flac': 'audio/flac',
      '.m4a': 'audio/mp4',
      '.aac': 'audio/aac',
      '.opus': 'audio/ogg',
      '.wma': 'audio/x-ms-wma',
    }[ext] || 'application/octet-stream'
  );
}

/* Roblox publishing is intentionally locked in this build. */
app.all('/api/roblox/publish', (req, res) => {
  res.status(501).json({
    error: 'Sedang dalam pengembangan',
    detail: 'Auto upload ke Roblox belum aktif di build ini. Unduh file lalu upload manual.',
    locked: true,
  });
});

app.get(['/converter', '/converter/', '/'], (req, res) => {
  res.sendFile(path.join(PUBLIC_DIR, 'index.html'));
});

app.use((req, res) => {
  if (req.path.startsWith('/api/')) return res.status(404).json({ error: 'Endpoint tidak ditemukan.' });
  res.status(404).sendFile(path.join(PUBLIC_DIR, 'index.html'));
});

app.listen(PORT, () => {
  console.log(`3Zane converter running → http://localhost:${PORT}/converter`);
});
