<div align="center">

# 3Zane Web Converter

**A working audio converter for Roblox creators — link or file in, playable audio out.**

[![Node](https://img.shields.io/badge/node-%3E%3D%2018-339933?logo=node.js&logoColor=white)](https://nodejs.org)
[![Express](https://img.shields.io/badge/express-4.x-000000?logo=express&logoColor=white)](https://expressjs.com)
[![ffmpeg](https://img.shields.io/badge/ffmpeg-required-007808?logo=ffmpeg&logoColor=white)](https://ffmpeg.org)
[![License](https://img.shields.io/badge/license-MIT-d4b36c)](./LICENSE)

</div>


A local rebuild of the [3Zane](https://3zane.my.id/converter) converter page: same layout,
same dark/gold workspace shell, but backed by a real pipeline that actually converts audio
instead of mocking it. Paste a YouTube, SoundCloud, Spotify or Apple Music link (or drop a file),
pick a format, shape it for Roblox, and download something that genuinely plays.

---

## Features

- **Real conversions** — MP3, OGG, WAV, FLAC, M4A, AAC, OPUS, WMA, produced by ffmpeg (not a fake progress bar).
- **Multi-platform extraction** — YouTube, SoundCloud, Spotify and Apple Music through
  [`scrapr`](https://github.com/prabowoalif/scrapr), with an automatic `yt-dlp` fallback when a
  scraper mirror is down.
- **Audio shaping** — speed (0.5×–3×), pitch (0.5×–2×), amplify (dB), normalize, remove silence,
  and start/end trimming.
- **Roblox workflow** — converts at a chosen speed and tells you exactly which
  `Sound.PlaybackSpeed` to set in Studio so playback returns to normal.
- **Live job progress** — staged pipeline (metadata → download → convert → validate → store) with
  percentage polling, so the UI shows where it actually is.
- **Activity + quota** — recent conversions and daily counters persist across restarts.
- **Waveform player** — canvas visualiser wired to a real `AudioContext` analyser on every result.

### Locked on purpose

**Auto upload to Roblox is disabled in this build.** Every publish button opens a
*"Sedang dalam pengembangan"* dialog, and the API refuses the request too:

```http
POST /api/roblox/publish  →  501  { "error": "Sedang dalam pengembangan", "locked": true }
```

Download the file and upload it manually until that lands.

---

## Requirements

| | |
|---|---|
| **Node.js** | 18 or newer |
| **ffmpeg + ffprobe** | static build, placed in `bin/` (see below) |
| **yt-dlp** *(optional)* | on `PATH` — used as the extraction fallback |

`bin/` is git-ignored because the binaries are ~100 MB each. Grab a build and drop the two
executables in:

```bash
# Windows (gyan.dev essentials build)
curl -L -o ffmpeg.zip https://www.gyan.dev/ffmpeg/builds/ffmpeg-release-essentials.zip
unzip ffmpeg.zip
mkdir -p bin && cp ffmpeg-*/bin/ffmpeg.exe ffmpeg-*/bin/ffprobe.exe bin/
```

```bash
# macOS / Linux
brew install ffmpeg          # or: sudo apt install ffmpeg
mkdir -p bin && ln -s "$(which ffmpeg)" bin/ffmpeg && ln -s "$(which ffprobe)" bin/ffprobe
```

The converter looks for binaries in this order: `FFMPEG_PATH` env var → `./bin` →
`@ffmpeg-installer` package → system `PATH`.

---

## Quick start

```bash
git clone https://github.com/ANTILUA-404/WEB-CONVERTER.git
cd WEB-CONVERTER
npm install

# ffmpeg binaries into bin/ — see Requirements above

node server.js
```

Open **http://localhost:3000/converter**.

Change the port with `PORT=8080 node server.js`.

---

## How it works

```
Browser (public/)
   │  POST /api/detect          → metadata for the meta card
   │  POST /api/convert         → { progressId }
   │  GET  /api/convert-progress/:id  (polled)
   │  GET  /api/preview/:name  → 206 Partial Content (seekable)
   ▼
server.js ──► lib/resolve.js ──► scrapr (primary)  ──► direct audio URL
           │                 └─► yt-dlp (fallback) ──► bestaudio stream
           └─► lib/convert.js ──► ffmpeg filter chain ──► data/out/<file>
```

### Extraction

`scrapr` is tried first, method by method:

| Platform | Chain |
|---|---|
| YouTube | `youtube.ytmp3` → `youtube.ytmp3gg` |
| SoundCloud | `soundcloud.klickaud` |
| Spotify | `spotify.spotisaver` → `spotidown` → `spotmate` |
| Apple Music | `applemusic.aplmate` |

Those mirrors change or rate-limit constantly, so there are two safety nets:

1. **Dead download URL** → the same track is re-resolved through `yt-dlp`.
2. **No result at all** → `yt-dlp` handles it directly (`ytsearch1:` for Spotify/Apple, since those
   services don't serve audio files).

scrapr usually omits duration and cover art, so both are topped up from
`yt-dlp --print` before the meta card renders. The response reports which path was used
(`resolvedVia: "scrapr" | "yt-dlp"`).

### Conversion

Formats and their encoders:

| Format | Encoder | Settings |
|---|---|---|
| `mp3` | libmp3lame | 320 kbps |
| `ogg` | libvorbis | q8 (~256 kbps) |
| `wav` | pcm_s16le | lossless PCM |
| `flac` | flac | lossless |
| `m4a` / `aac` | aac | 256 kbps |
| `opus` | libopus | 192 kbps |
| `wma` | wmav2 | 192 kbps |

Filter graph, applied in this order:

1. `silenceremove` — *Remove silence*
2. `atempo` chain — **Speed** (tempo only, pitch preserved; chained because `atempo` only accepts 0.5–2 per instance)
3. `asetrate` → `aresample` → `atempo` inverse — **Pitch** (pitch only, length preserved)
4. `volume` — **Amplify**
5. `loudnorm` — **Normalize**

> **Trim is applied as an *input* option** (`-ss` / `-t` before `-i`). ffmpeg's `-t` after a filter
> limits *output* duration, so putting it after `atempo` would silently trim the wrong amount of
> source audio. Doing it on the input side keeps `Start` / `End` values in source time regardless of
> the tempo factor.

Defaults mirror the reference page: OGG, speed 2.3×, amplify −2 dB, pitch 0 %, Roblox target
`PlaybackSpeed` 0.4347 — i.e. convert fast, then set `Sound.PlaybackSpeed` in Studio to restore
normal speed.

---

## API

| Method | Endpoint | Description |
|---|---|---|
| `POST` | `/api/detect` | Resolve title, artist, duration, cover and available formats for a URL |
| `POST` | `/api/convert` | Start a URL conversion → `{ accepted, progressId }` |
| `POST` | `/api/convert-upload` | Start a conversion from an uploaded file (multipart, ≤ 50 MB) |
| `GET` | `/api/convert-progress/:id` | `{ stage, message, percent, result, error }` |
| `GET` | `/api/file/:name` | Download the converted file |
| `GET` | `/api/preview/:name` | Inline audio, supports Range requests for seeking |
| `GET` | `/api/activity` | Recent conversions for the activity feed |
| `GET` | `/api/account` | Plan, limits and daily usage |
| `ALL` | `/api/roblox/publish` | **Locked** → `501 Sedang dalam pengembangan` |

---

## Project structure

```
server.js              Express app — jobs, progress, file serving, locked endpoint
lib/resolve.js         scrapr extraction chain + yt-dlp fallback + downloader
lib/convert.js         ffmpeg/ffprobe wrapper, filter graph, format table
public/
  index.html           The page (mirrors the reference DOM)
  app.js               UI state, detect/convert flow, waveform player, locked modal
  Profile.png          Brand mark / splash logo
  assets/
    site.css           Reference stylesheet (unchanged)
    app.css            Additions: modal, toasts, [hidden] fix
vendor/scrapr/         Vendored scraper library (MIT) — github.com/prabowoalif/scrapr
bin/                   ffmpeg.exe + ffprobe.exe  (git-ignored)
data/out/              Converted files          (git-ignored)
data/activity.json     Persisted activity log   (git-ignored)
```

`vendor/scrapr` is committed as plain source (its own `.git` is ignored) because the package was
never published to npm — `npm i @alifxz/scrapr` returns 404. To update it:

```bash
rm -rf vendor/scrapr
git clone --depth 1 https://github.com/prabowoalif/scrapr.git vendor/scrapr
rm -rf vendor/scrapr/.git
```

---

## Notes & limitations

- **No login.** The workspace runs as a local guest; the Discord button and the non-converter
  sidebar pages open an info dialog instead of navigating.
- **In-memory jobs.** Conversion jobs live in the server process — restarting mid-conversion loses
  the job (files already written to `data/out` survive).
- **Extraction is best-effort.** These platforms fight back; if a link fails, try again or use a
  direct YouTube URL. `yt-dlp` is the reliable path — keep it updated (`yt-dlp -U`).
- **Respect the source platforms.** Use this for content you have the rights to convert.

---

## Credits

- Scraper: [prabowoalif/scrapr](https://github.com/prabowoalif/scrapr) (MIT)
- Layout & visual design derived from [3zane.my.id](https://3zane.my.id/converter)
- Icons: Lucide-style paths
- Built on [Express](https://expressjs.com), [ffmpeg](https://ffmpeg.org), [yt-dlp](https://github.com/yt-dlp/yt-dlp)

## License

[MIT](./LICENSE)
